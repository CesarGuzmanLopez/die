(function (blocks, editor, components, element, blockEditor) {
  const { createElement: el } = element;
  const { registerBlockType } = blocks;
  const { MediaUpload, InspectorControls, ColorPalette } = editor;
  const { PanelBody, TextControl, SelectControl, RangeControl } = components;
  const { useBlockProps } = blockEditor;

  const blockConfig = {
    title: "Bloque Personalizado",
    icon: "format-image",
    category: "media",
    attributes: {
      mediaURL: {
        type: "string",
        source: "attribute",
        selector: "img",
        attribute: "src",
      },
      mediaID: { type: "number" },
      texto: { type: "string", default: "Texto predeterminado" },
      urlBoton: { type: "string", default: "http://www.ejemplo.com/" },
      posicionTexto: { type: "string", default: "center" },
      efectoVisual: { type: "string", default: "degradado" },
      direccionDegradado: { type: "string", default: "to bottom" },
      nivelTransparencia: { type: "number", default: 0.5 },
      colorTexto: { type: "string", default: "#ffffff" },
      ancho: { type: "number", default: 100 },
      alto: { type: "number", default: 50 },
    },
    edit: function (props) {
      const {
        attributes: {
          mediaURL,
          mediaID,
          texto,
          urlBoton,
          posicionTexto,
          efectoVisual,
          direccionDegradado,
          nivelTransparencia,
          colorTexto,
          ancho,
          alto,
        },
        setAttributes,
      } = props;

      const blockProps = useBlockProps({
        style: {
          width: ancho + "%",
          height: alto + "vh",
          backgroundImage: `url(${mediaURL})`,
        },
      });

      const onSelectImage = (media) => {
        setAttributes({ mediaID: media.id, mediaURL: media.url });
      };

      return el(
        "div",
        blockProps,
        el(
          InspectorControls,
          {},
          el(
            PanelBody,
            { title: "Configuraciones del Bloque", initialOpen: true },
            el(MediaUpload, {
              onSelect: onSelectImage,
              allowedTypes: "image",
              value: mediaID,
              render: (obj) =>
                el(
                  components.Button,
                  { className: "button button-large", onClick: obj.open },
                  !mediaID ? "Seleccionar Imagen" : "Cambiar Imagen"
                ),
            }),
            el(TextControl, {
              label: "Texto",
              value: texto,
              onChange: (value) => setAttributes({ texto: value }),
            }),
            el(TextControl, {
              label: "URL del botón",
              value: urlBoton,
              onChange: (value) => setAttributes({ urlBoton: value }),
            }),
            el(SelectControl, {
              label: "Posición del Texto",
              value: posicionTexto,
              options: [
                { label: "Centro", value: "center" },
                { label: "Arriba", value: "flex-start" },
                { label: "Abajo", value: "flex-end" },
                { label: "Derecha", value: "flex-end" },
                { label: "Izquierda", value: "flex-start" },
              ],
              onChange: (value) => setAttributes({ posicionTexto: value }),
            }),
            el(SelectControl, {
              label: "Efecto Visual",
              value: efectoVisual,
              options: [
                { label: "Degradado", value: "degradado" },
                { label: "Traslúcido", value: "traslucido" },
              ],
              onChange: (value) => setAttributes({ efectoVisual: value }),
            }),
            el(TextControl, {
              label: "Dirección del Degradado",
              value: direccionDegradado,
              onChange: (value) => setAttributes({ direccionDegradado: value }),
            }),
            el(RangeControl, {
              label: "Nivel de Transparencia",
              value: nivelTransparencia,
              onChange: (value) => setAttributes({ nivelTransparencia: value }),
              min: 0,
              max: 1,
              step: 0.01,
            }),
            el(ColorPalette, {
              label: "Color del Texto",
              value: colorTexto,
              onChange: (value) => setAttributes({ colorTexto: value }),
            }),
            el(RangeControl, {
              label: "Ancho del Bloque (%)",
              value: ancho,
              onChange: (value) => setAttributes({ ancho: value }),
              min: 10,
              max: 100,
              step: 1,
            }),
            el(RangeControl, {
              label: "Alto del Bloque (vh)",
              value: alto,
              onChange: (value) => setAttributes({ alto: value }),
              min: 10,
              max: 100,
              step: 1,
            })
          )
        ),
        el(
          "div",
          {
            className: "contenido-bloque",
            style: { justifyContent: posicionTexto, color: colorTexto },
          },
          el("h2", null, texto),
          el(
            "a",
            { href: urlBoton, style: { color: colorTexto } },
            "Conocer sdfdfMás"
          )
        )
      );
    },
    save: function ({
      attributes: {
        mediaURL,
        texto,
        urlBoton,
        posicionTexto,
        efectoVisual,
        direccionDegradado,
        nivelTransparencia,
        colorTexto,
        ancho,
        alto,
      },
    }) {
      const blockProps = useBlockProps.save({
        style: {
          width: ancho + "%",
          height: alto + "vh",
          backgroundImage: `url(${mediaURL})`,
        },
      });

      const estiloContenido = {
        justifyContent: posicionTexto,
        color: colorTexto,
      };

      return el(
        "div",
        blockProps,
        el(
          "div",
          { className: "contenido-bloque", style: estiloContenido },
          el("h2", null, texto),
          el(
            "a",
            { href: urlBoton, style: { color: colorTexto } },
            "Conocer Más"
          )
        )
      );
    },
  };

  registerBlockType("mi-plugin/bloque-personalizado", blockConfig);
})(
  window.wp.blocks,
  window.wp.editor,
  window.wp.components,
  window.wp.element,
  window.wp.blockEditor
);

(function (wp) {
  const { subscribe } = wp.data;

  let lastBlocks = [];

  subscribe(() => {
    const blocks = wp.data.select("core/block-editor").getBlocks();
    if (blocks.length !== lastBlocks.length) {
      lastBlocks = blocks;
      wp.data.dispatch("core/editor").lockPostSaving("bloque4");
      wp.data.dispatch("core/editor").savePost();
    }
  });
})(window.wp);
