<?php
/**
 * The template for displaying the footer in PWA.
 *
 * @package CtemaWP WordPress theme
 * @since   1.8.8
 */

?>

	<?php wp_footer(); ?>
	</body>
</html>
