export const options = ctemawpLocalize;
